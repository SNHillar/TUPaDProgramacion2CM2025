package myprojectjava;

public class MyProjectJava {

    public static void main(String[] args) {

        HolaMundo saludo = new HolaMundo();
        
        saludo.saludar();
        
    }
}
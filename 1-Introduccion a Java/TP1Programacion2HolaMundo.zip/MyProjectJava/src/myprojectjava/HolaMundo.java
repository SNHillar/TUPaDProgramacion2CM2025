
package myprojectjava;

public class HolaMundo {
    
    public static void saludar(){
        
        System.out.println("Hola, Java!");
    }
}

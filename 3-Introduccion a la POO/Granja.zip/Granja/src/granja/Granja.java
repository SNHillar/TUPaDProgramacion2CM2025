/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package granja;

/*
Gestión de Gallinas en Granja Digital 
a. Crear una clase Gallina con los atributos: idGallina, edad, 
huevosPuestos. 

Métodos requeridos: ponerHuevo(), envejecer(), mostrarEstado(). 
Tarea: Crear dos gallinas, simular sus acciones (envejecer y poner huevos), y 
mostrar su estado
 */
public class Granja {

    
    public static void main(String[] args) {
        // cremos dos gallinas
        Gallina gallina1 = new Gallina(1, 2, 0);
        Gallina gallina2 = new Gallina(2, 1, 2);
        
        // mostramos estado actual
        gallina1.mostrarEstado();
        gallina1.ponerHuevo();                          // simulamos acciones           TODO: menu
        gallina1.ponerHuevo();
        gallina1.envejecer();
        gallina1.mostrarEstado();
        
        System.out.println("");
        System.out.println("");
        
        
        gallina2.mostrarEstado();
        gallina2.ponerHuevo();
        gallina2.envejecer();
        gallina2.envejecer();
        gallina2.ponerHuevo();
        gallina2.mostrarEstado();
        
        
    }
    
}

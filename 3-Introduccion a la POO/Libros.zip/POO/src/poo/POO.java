
package poo;

import java.util.Scanner;

/*

3. Encapsulamiento con la Clase Libro

a. Crear una clase Libro con atributos privados: titulo, autor,
añoPublicacion.



Tarea: Crear un libro, intentar modificar el año con un valor inválido y luego con
uno válido, mostrar la información final.

 */
public class POO {

    
    public static void main(String[] args) {
        
        // TODO code application logic here
        Libro libro = new Libro();
        Scanner input = new Scanner(System.in);
        
        
        
        System.out.println("Esta es la informacion actual de tu libro");
        libro.mostrarInfo();
        
        System.out.println("===================================");
        System.out.println("Modificacion del anio de publicacion del libro");
        
        boolean bandera;
        
        do{
            
            System.out.println("Ingresa el anio de publicacion a colocar: " );
            int nuevoAnio = input.nextInt();
            
            bandera = libro.setAnioPublicacion(nuevoAnio); // true si es exitoso
            
            if(bandera){   
                System.out.println("Anio modificado correctamente!\n A continuacion, te mostramos actualizado!");
                libro.mostrarInfo();
            }
        }while(!bandera);
        
    }
    
}

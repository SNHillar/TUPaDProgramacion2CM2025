
package poo;


public class Libro {
    
    private String titulo = "Mi libro prueba";
    private String autor = "Yo mismo";
    private int anioPublicacion = 2025;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }
    
    public void mostrarInfo(){
        System.out.println("titulo: " + getTitulo());
        System.out.println("autor: " + getAutor());
        System.out.println("anio publicacion: " + getAnioPublicacion());
    }
    
    

    public boolean setAnioPublicacion(int anioPublicacion) {
        if(anioPublicacion >= 1450 && anioPublicacion <= 2025 ){
            this.anioPublicacion = anioPublicacion;
            return true;
        } else {
            System.out.println("El anio de publicacion no es valido.");
            return false;
        }
    }
    
    
    
}


package naveespacial;


public class Nave {
    
    private String nombre;
    private double combustible;

    public Nave(String nombre, double combustible) {
        this.nombre = nombre;
        this.combustible = combustible;
    }
    
    public void despegar(){
        System.out.println("Bienvenidos a " + nombre);
        System.out.println("El despegue nos quita 10 unidades de combustible!");
        combustible -= 10;
        System.out.println("El combustible restante es: " + combustible + " unidades");
    }
    
    public void avanzar(double distancia){
        if(combustible >= distancia){
            combustible -= distancia;
            System.out.println("Has avanzado " + distancia + " unidades, ahora el combustible restante es: " + combustible);
        }else{
            System.out.println("Lo siento, no hay combustible suficiente para avanzar!");
        }
    }
    
    
    public void recargarCombustible(double cantidad){
        combustible += cantidad;
        System.out.println("Has recargado " + cantidad + " de combustible, y la nueva cantidad es: " + combustible);
    }
    
}

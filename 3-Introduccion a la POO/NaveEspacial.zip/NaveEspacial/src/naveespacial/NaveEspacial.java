package naveespacial;

import java.util.Scanner;

/*
 Simulación de Nave Espacial

Crear una clase NaveEspacial con los atributos: nombre, combustible.


Métodos requeridos: despegar(), avanzar(distancia),
recargarCombustible(cantidad), mostrarEstado().


Reglas: Validar que haya suficiente combustible antes de avanzar y evitar que
se supere el límite al recargar.


Tarea: Crear una nave con 50 unidades de combustible, intentar avanzar sin
recargar, luego recargar y avanzar correctamente. Mostrar el estado al final.

 */
public class NaveEspacial {

    
    public static void main(String[] args) {
        Nave nave = new Nave("Mi nave del espacio", 50);
        System.out.println("Para despegar la nave, maca 1!");
        Scanner input = new Scanner(System.in);
        boolean continuar = true;
        boolean haDespegado = false;
        
        while (continuar) {
            System.out.println("\nMenu:");
            System.out.println("1. Despegar");
            System.out.println("2. Avanzar");
            System.out.println("3. Recargar combustible");
            System.out.println("4. Salir");
            System.out.print("Elige una opcion: ");
            int opcion = input.nextInt();
            
            
            switch (opcion) {
                case 1:
                    if (!haDespegado) {
                        nave.despegar();
                        haDespegado = true;
                        System.out.println("¡Hemos despegado!");
                    } else {
                        System.out.println("¡Ya hemos despegado!");
                    }
                    break;
                case 2:
                    if (!haDespegado) {
                        System.out.println("¡Debes despegar primero!");
                    } else {
                        System.out.print("¿Qué distancia quieres avanzar? ");
                        int distancia = input.nextInt();
                        nave.avanzar(distancia);
                    }
                    break;
                case 3:
                    System.out.println("Ingrese la cantidad de unidades a recargar");
                    double cantidad = input.nextDouble();
                    nave.recargarCombustible(cantidad);
                    break;
                case 4:
                    System.out.println("Saliendo del simulador...");
                    continuar = false;
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    
}
}
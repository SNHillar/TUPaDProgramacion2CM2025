/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javatp3;


public class Estudiante {

    private String nombre = "Saul";
    private String apellido = "Hillar";
    private String curso = "Programacion";
    private double calificacion = 9.12;

    
    
    /*
    Métodos requeridos: mostrarInfo(), subirCalificacion(puntos),
    bajarCalificacion(puntos).
    */
    
    public void mostrarInfo(){
        System.out.println("Nombre: " + getNombre() + "\nApellido: " + getApellido() + "\nCurso: " + getCurso() + "\nCalificacion: " + getCalificacion());
    }
    
    public void subirCalificacion(double puntos){
        if(puntos >= 0 && puntos <= 10){
            double nuevaCalificacion = calificacion + puntos;
            if(nuevaCalificacion > 10){
                nuevaCalificacion = 10; //para asegurarnos que 10 es el limite
            }
            setCalificacion(nuevaCalificacion);
        }else{
            System.out.println("Los puntos deben ser entre 0 y 10.");
        }
    }
    
    public void bajarCalificacion(double puntos){
        if(puntos >= 0 && puntos <= 10){
            double nuevaCalificacion = calificacion - puntos;
            if(nuevaCalificacion < 0){
                nuevaCalificacion = 0; //para asegurarnos que 0 es el limite
            }
            setCalificacion(nuevaCalificacion);
            }else{
            System.out.println("Los puntos deben ser entre 0 y 10.");
        }
    }

    private String getNombre() {
        return nombre;
    }

    private String getApellido() {
        return apellido;
    }

    private String getCurso() {
        return curso;
    }

    private double getCalificacion() {
        return calificacion;
    }

    private void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }
    
}

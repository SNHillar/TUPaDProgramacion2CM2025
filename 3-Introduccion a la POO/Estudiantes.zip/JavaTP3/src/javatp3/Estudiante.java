/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javatp3;


public class Estudiante {

    private String nombre;
    private String apellido;
    private String curso;
    private double calificacion;

    
    
    /*
    Métodos requeridos: mostrarInfo(), subirCalificacion(puntos),
    bajarCalificacion(puntos).
    */

    public Estudiante(String nombre, String apellido, String curso, double calificacion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.curso = curso;
        this.calificacion = calificacion;
    }
    
    
    
    
    public void mostrarInfo(){
        System.out.println("Nombre: " + nombre + "\nApellido: " + apellido + "\nCurso: " + curso + "\nCalificacion: " + calificacion);
    }
    
    public void subirCalificacion(double puntos){
        if(puntos >= 0 && puntos <= 10){
            double nuevaCalificacion = calificacion + puntos;
            if(nuevaCalificacion > 10){
                nuevaCalificacion = 10; //para asegurarnos que 10 es el limite
            }
            setCalificacion(nuevaCalificacion);
        }else{
            System.out.println("Los puntos deben ser entre 0 y 10.");
        }
    }
    
    public void bajarCalificacion(double puntos){
        if(puntos >= 0 && puntos <= 10){
            double nuevaCalificacion = calificacion - puntos;
            if(nuevaCalificacion < 0){
                nuevaCalificacion = 0; //para asegurarnos que 0 es el limite
            }
            setCalificacion(nuevaCalificacion);
            }else{
            System.out.println("Los puntos deben ser entre 0 y 10.");
        }
    }

    private void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }
    
}

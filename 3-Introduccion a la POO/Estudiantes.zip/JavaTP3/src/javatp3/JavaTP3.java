/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javatp3;


public class JavaTP3 {
    /*
    Registro de Estudiantes
    
    a. Crear una clase Estudiante con los atributos: nombre, apellido, curso,
    calificación.
    
    
    Métodos requeridos: mostrarInfo(), subirCalificacion(puntos),
    bajarCalificacion(puntos).
    
    Tarea: Instanciar a un estudiante, mostrar su información, aumentar y disminuir
    calificaciones.
    */
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        Estudiante saul = new Estudiante(); // Creamos la instancia del estudiante, es decir, un alumno
        
        //nos abstraemos a mostrar la info, hacer modificaciones desde el metodo y mostrar resultados.
        saul.mostrarInfo();
        saul.bajarCalificacion(2);
        
        
        saul.mostrarInfo();
        
        
        saul.subirCalificacion(1);
        saul.mostrarInfo();
    }
    
}


package mascotas;


public class Principal {

    /*
    2. Registro de Mascotas
    a. Crear una clase Mascota con los atributos: nombre, especie, edad.
    Métodos requeridos: mostrarInfo(), cumplirAnios().
    
    
    Tarea: Crear una mascota, mostrar su información, simular el paso del tiempo y
    verificar los cambios.
    
    */
    public static void main(String[] args) {
        
        Mascota bartolo = new Mascota();
        
        
        bartolo.mostrarInfo();
        System.out.println("Ha pasado un anio, y bartolo festejo su cumpleanios");
        bartolo.cumplirAnios();
        bartolo.mostrarInfo();
    }
    
}

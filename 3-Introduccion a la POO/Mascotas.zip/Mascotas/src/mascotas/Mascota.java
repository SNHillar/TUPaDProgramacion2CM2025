
package mascotas;

/**
 2. Registro de Mascotas
a. Crear una clase Mascota con los atributos: nombre, especie, edad.
Métodos requeridos: mostrarInfo(), cumplirAnios().
 */
public class Mascota {
    
    private String nombre = "Bartolo";
    private String especie = "Dogo Argentino";
    private int edad = 5;
    
    
    public void cumplirAnios(){
        int nuevaEdad = edad + 1;
        setEdad(nuevaEdad);
    }
    
    public void mostrarInfo(){
        System.out.println("Nombre de la mascota: " + getNombre());
        System.out.println("Especie: " + getEspecie());
        System.out.println("Edad: " + getEdad() + " anios");
    }

    private String getNombre() {
        return nombre;
    }

    private String getEspecie() {
        return especie;
    }

    private int getEdad() {
        return edad;
    }

    private void setEdad(int edad) {
        this.edad = edad;
    }
    
    
    
}

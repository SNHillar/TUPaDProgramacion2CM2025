/*
int id: Identificador único del empleado.
String nombre: Nombre completo.
String puesto: Cargo que desempeña.
double salario: Salario actual.
static int totalEmpleados: Contador global de empleados creados.
 */
package gestionempleados;


public class Empleado {
    
    private int id;
    private String nombre;
    private String puesto;
    private double salario;
    static int totalEmpleados = 0;
    static int contador;

    public Empleado(int id, String nombre, String puesto, double salario) {
        this.id = id;
        this.nombre = nombre;
        this.puesto = puesto;
        this.salario = salario;
        totalEmpleados++;
        contador++;
    }

    public Empleado(String nombre, String puesto) {
        this.id = contador;
        this.nombre = nombre;
        this.puesto = puesto;
        totalEmpleados++;
        contador++;
    }
    
    public void actualizarSalario(double porcentaje){
        salario += (salario * porcentaje) / 100; 
    }
    
    public void actualizarSalario(int cantidad){
        salario += cantidad;
    }

    @Override
    public String toString() {
        return "Empleado{" + "id=" + id + ", nombre=" + nombre + ", puesto=" + puesto + ", salario=" + salario + '}';
    }
    
    public static void mostrarTotalEmpleados(){
        System.out.println("Total Empleados: " + totalEmpleados);
    }
    
}

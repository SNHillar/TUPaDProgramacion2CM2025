
package gestionempleados;

import static gestionempleados.Empleado.mostrarTotalEmpleados;


public class Main {

   
    public static void main(String[] args) {
       
        Empleado e1 = new Empleado(1, "Saul", "programacion", 1000);
        Empleado e2 = new Empleado("Jorge", "IT");
        Empleado e3 = new Empleado(4, "Jose", "DevOps", 4000);
        Empleado e4 = new Empleado(3, "Genesis", "Data", 5000);
        Empleado emp5 = new Empleado("Camila", "Marketing");
        Empleado emp6 = new Empleado("Fede", "Ventas");
        
        System.out.println(e1);
        System.out.println("");
        System.out.println(e2);
        System.out.println("");
        System.out.println(e3);
        System.out.println("");
        System.out.println(e4);
        System.out.println("");
        System.out.println(emp5);
        System.out.println("");
        System.out.println(emp6);
        System.out.println("");
        mostrarTotalEmpleados();
    }
    
}

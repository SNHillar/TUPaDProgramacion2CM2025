
package ejercicio5;


public class Main {

 
    public static void main(String[] args) {
        
        Computadora compu = new Computadora("MSI", "MSI1234366", "Z370", "ASF23234-MSI"); // 1.1 Composicion
        Propietario user = new Propietario("Jose", "42523456");                                                         // la pasamos como argumentos primitivos
        
        user.setComputadora(compu); // relacion unidireccional, mediante 1 setter 
        System.out.println(user);
    }
    
}


package ejercicio6;


public class Cliente {
    
    private String nombre;
    private String telefono;
    private Mesa mesa;
    

    public Cliente(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", telefono=" + telefono + ", mesa=" + mesa + '}';
    }
    
    
    
    
}

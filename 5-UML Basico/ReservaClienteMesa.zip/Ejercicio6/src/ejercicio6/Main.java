
package ejercicio6;


public class Main {

   
    public static void main(String[] args) {
        
        Cliente cliente = new Cliente("Pedro", "11 123335325");
        Mesa mesa = new Mesa("10", "4");
        Reserva reserva = new Reserva("05/02/2025", "12:00hs", mesa); // 1.1 Agregacion, si le paso null la mesa aun existe
        
        reserva.setCliente(cliente);
        System.out.println(reserva);
    }
    
}

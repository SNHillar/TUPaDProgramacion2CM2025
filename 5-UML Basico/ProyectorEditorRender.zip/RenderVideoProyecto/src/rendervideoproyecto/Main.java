
package rendervideoproyecto;


public class Main {


    public static void main(String[] args) {
        Proyecto proyecto1 = new Proyecto("Mi primer proy", "120 minutos");
        EditorVideo editor = new EditorVideo();
        
        editor.exportar("MP3", proyecto1);
        
    }
    
}


package usuariogencodigo;


public class Main {

    public static void main(String[] args) {  
        
        
        Usuario user = new Usuario("Saul", "mailfalso@mailfalso");
        Usuario user2 = new Usuario("Jorge", "akgwe@asgfasg");
        GeneradorQR posnet = new GeneradorQR();
        
        posnet.generar("12312-04925812", user); // instanciamos el codigoqr desde el metodo
        posnet.generar("12301-154657", user2);
    }
    
}

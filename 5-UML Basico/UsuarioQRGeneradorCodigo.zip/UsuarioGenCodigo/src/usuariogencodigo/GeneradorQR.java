
package usuariogencodigo;


public class GeneradorQR {
    
    public void generar(String valor, Usuario user){
        
        CodigoQR codigo = new CodigoQR(valor, user);
         
        
        System.out.println(codigo);
    }
}


package ejercicio2;


public class Main {

    
    public static void main(String[] args) {
        
        
        Usuario user = new Usuario("Carlos", "41562923");
        Bateria batt = new Bateria("Apple", 4500);
        Celular iphone16 = new Celular("134-2354251", "Apple", "Iphone 16 Pro Max", batt);
        
        
        user.setCelular(iphone16);
        System.out.println(user);
    }
    
}

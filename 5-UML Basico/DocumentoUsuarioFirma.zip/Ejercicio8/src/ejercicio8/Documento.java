
package ejercicio8;


public class Documento {
    
    private String titulo;
    private String contenido;
    private FirmaDigital firma;

    public Documento(String titulo, String contenido, String codigoHash, String fecha, String nombreUsuario, String emailUsuario) {
        this.titulo = titulo;
        this.contenido = contenido;
        
        Usuario user = new Usuario(nombreUsuario, emailUsuario);
        
        this.firma = new FirmaDigital(codigoHash, fecha, user);
    }
    
    public void mostrar(){
        System.out.println("Titulo: " + titulo + " Contenido: " + contenido + " Firma: " + firma);
    }
}

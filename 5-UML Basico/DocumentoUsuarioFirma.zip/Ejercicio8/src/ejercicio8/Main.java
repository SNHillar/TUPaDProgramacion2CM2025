
package ejercicio8;


public class Main {

    
    public static void main(String[] args) {
        
        Documento doc = new Documento("Contrato de Trabajo", "Este es el contenido del contrato", "ABC123DEF456GHI789","06/05/2023", "Juan Pérez", "juan.perez@example.com");
        
        doc.mostrar();
    }
    
}


package ejercicio8;


public class FirmaDigital {
    
    private String hashCode;
    private String fecha;
    private Usuario user;

    public FirmaDigital(String hashCode, String fecha,Usuario user) {
        this.hashCode = hashCode;
        this.fecha = fecha;
        this.user = user;
    }

    @Override
    public String toString() {
        return "FirmaDigital{" + "hashCode=" + hashCode + ", fecha=" + fecha + ", user=" + user + '}';
    }

    

    
    
    
    
    
}

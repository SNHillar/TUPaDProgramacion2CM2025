
package javaapplication15;

public class Main {


    public static void main(String[] args) {
        
        
        //instanciamos las clases
        Contribuyente jorge = new Contribuyente("Jorge", "20-41567023-1");
        Impuesto iva = new Impuesto(1000);
        Calculadora casio = new Calculadora();
        
        
        iva.setContribuyente(jorge);
        System.out.println(iva);
        casio.calcular(iva);
        
    }
    
}


package javaapplication15;


public class Calculadora {
    
    
    public void calcular(Impuesto impuesto){
        
        double iva = 0.21;
        double impuestoCalculado = impuesto.getMonto() * iva;
        
        
        System.out.println("El impuesto a pagar es: " + impuestoCalculado);
        
        double total = impuesto.getMonto() + impuestoCalculado;
        
        System.out.println("El total a pagar es: " + total);
    }
    
    
}

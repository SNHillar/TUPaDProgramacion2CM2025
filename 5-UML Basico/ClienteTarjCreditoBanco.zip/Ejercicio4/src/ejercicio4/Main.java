
package ejercicio4;


public class Main {

    public static void main(String[] args) {
        
        Banco banco = new Banco("VISA", "30-23933522-2");
        TarjetaCredito tarjeta = new TarjetaCredito("12345", "06/2026", banco);
        Cliente cliente = new Cliente("Jorge", "23897645");
        
        cliente.setTarjeta(tarjeta);
        System.out.println(cliente);
    }
    
}

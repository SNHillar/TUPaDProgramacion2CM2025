
package ejercicio1_c;


public class Main {

    public static void main(String[] args) {
        Editorial editorial = new Editorial("Ficticia", "Calle Falsa 123");
        Autor autor = new Autor("Neruda", "Argentina");
        Libro libro = new Libro("La bella durmiente", "12153-AE", editorial);
        libro.setAutor(autor);
        System.out.println(libro);
    }
    
}

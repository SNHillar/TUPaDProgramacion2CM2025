/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1_a;

/**
 *
 * @author meyne
 */
public class Pasaporte {
    
    private String numero;
    private String fechaEmision;
    private Foto foto;
    private Titular titular;

    public Pasaporte(String numero, String fechaEmision, String urlFoto) {
        this.numero = numero;
        this.fechaEmision = fechaEmision;
        this.foto = new Foto(urlFoto);
    }

    public void setTitular(Titular titular) {
        this.titular = titular;
        if(titular != null && titular.getPasaporte() != this){
            titular.setPasaporte(this);
        }
    }

    public Titular getTitular() {
        return titular;
    }
    
//    public void mostrarInfo(){
//        System.out.println("Titular: " + titular + "\nNumero: " + numero + "\nFecha Emision: "+ fechaEmision + "\nFoto: " + foto.getUrlImagen());
//    }

    @Override
    public String toString() {
        return "{" + "Numero=" + numero + ", fechaEmision=" + fechaEmision + ", foto=" + foto.getUrlImagen() + ", titular=" + titular.getNombre() + '}';
    }
}

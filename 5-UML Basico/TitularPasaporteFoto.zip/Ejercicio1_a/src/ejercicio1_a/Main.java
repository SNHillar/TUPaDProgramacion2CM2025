
package ejercicio1_a;


public class Main {

    
    public static void main(String[] args) {
        
        Titular persona1 = new Titular("Saul", "41600355");
        Pasaporte pasaporte1 = new Pasaporte("1A-1242", "17/02/2023", "foto.png");
        
        persona1.setPasaporte(pasaporte1); //seteamos el pasaporte al titular
        pasaporte1.setTitular(persona1);
        persona1.mostrar();
    }
    
}

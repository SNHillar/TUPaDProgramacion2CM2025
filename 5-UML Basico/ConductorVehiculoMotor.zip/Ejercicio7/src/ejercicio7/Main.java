
package ejercicio7;

public class Main {

   
    public static void main(String[] args) {
        
        Motor motor = new Motor("Nafta", "2312513536");
        Vehiculo auto = new Vehiculo("AB 245 AH", "Yaris", motor); // 1.1 Agregacion
        Conductor persona1 = new Conductor("Jorge", "B2");
        
        persona1.setVehiculo(auto); // 1.1 bidireccional
        persona1.mostrar();
    }
    
}

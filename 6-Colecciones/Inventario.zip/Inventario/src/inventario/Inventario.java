
package inventario;

import java.util.ArrayList;
import java.util.List;


public class Inventario {
    
    private List<Producto> productos = new ArrayList<>();
    
    public void agregarProducto(Producto p){
        if(p != null && !productos.contains(p)){
            productos.add(p);
        }
    }
    
    public void listarProductos(){
        for(Producto p : productos){
            System.out.println(p);
        }
    }
    
    public Producto buscarProductoPorId(String id){
        Producto productoEncontrado = null;
        int i = 0;
        while(i < productos.size() && productoEncontrado == null){
            Producto producto = this.productos.get(i);
            if(producto.getId().equalsIgnoreCase(id)){
                System.out.println("Producto Encontrado: " + producto);
                return producto;
            }
            i++;
        }
        System.out.println("No se encontro el producto con id: " + id);
        return productoEncontrado;
    }
    
    
    public Producto eliminarProducto(String id){
        Producto productoABorrar = buscarProductoPorId(id);
        System.out.println("Producto Eliminado.");
        this.productos.remove(productoABorrar);
        return productoABorrar;
    }
    
    
    
    
}

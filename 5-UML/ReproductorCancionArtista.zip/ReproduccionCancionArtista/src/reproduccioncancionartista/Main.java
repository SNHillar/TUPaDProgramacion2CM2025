
package reproduccioncancionartista;


public class Main {

 
    public static void main(String[] args) {
        
        Artista ceratti = new Artista("Ceratti", "Rock&Roll");
        Cancion teParaTres = new Cancion("Te para tres", "Ceratti");
        Reproductor mp3 = new Reproductor();
        
        
        teParaTres.setArtista(ceratti);
        
        
        mp3.reproducir(teParaTres);
        
        teParaTres.setArtista(null);
        
        mp3.reproducir(teParaTres);
        
        System.out.println(ceratti);
    }
    
}


package reproduccioncancionartista;


public class Reproductor {
    
    public void reproducir(Cancion cancion){
        
        System.out.println("Reprodiendo cancion: " + cancion.getTitulo() + "\nArtista: " + cancion.getArtista());
        
    }
}
